package com.example.temperatureapp;

public class Graphing {

}
